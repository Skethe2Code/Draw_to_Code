from django.shortcuts import render
from .forms import ImageForm
from django.http import HttpResponse
from django.shortcuts import render,redirect
from .gray import GrayCon
# Create your views here.
def index(request):
    if request.method=="POST":
        form = ImageForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            obj=GrayCon(request.FILES['image'])
            print(obj)
            return render(request, 'display.html',{'im' : obj})
    else:
        form=ImageForm()
    return render(request, 'index.html', {'form' : form})
def success(request):
    return render((request, 'index.html',{'im' : obj}))
    # return HttpResponse('successfully uploaded')