import cv2
def GrayCon(img):
    # print(str(img))
    image = cv2.imread("C:/Users/sneha/Desktop/wiseproj/Mlproject/media/img/21/"+str(img))
    # print(image,"hello")
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # print(gray_image)
    h=cv2.imwrite("media/"+str(img),gray_image)
    return "media/"+str(img)